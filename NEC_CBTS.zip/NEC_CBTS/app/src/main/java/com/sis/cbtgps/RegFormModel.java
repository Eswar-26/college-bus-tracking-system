package com.sis.cbtgps;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class RegFormModel {
    public String rno;
    public String pwd;
    public String name;
    public String year;
    public String semester;
    public String department;
    public String id;
    public String password;
    public String number;

    public String dname;
    public RegFormModel() {

    }

    public RegFormModel(String strRno, String strPwd, String strName,
                        String strYear, String strSem, String strDept) {
        this.rno = strRno;
        this.pwd = strPwd;
        this.name = strName;
        this.year = strYear;
        this.semester = strSem;
        this.department = strDept;
    }
    public RegFormModel(String drid, String drpw, String drname, String drnum) {
        this.id = drid;
        this.password = drpw;
        this.dname = drname;
        this.number = drnum;
    }


    public int getId() {
        return 0;
    }

    public int getDname() {
        return 0;
    }

    public int getNumber() {
        return 0;
    }
}
