package com.sis.cbtgps;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AdminActivity extends AppCompatActivity implements StudentAdapter.StudentListener {
    RelativeLayout admin_add_student;
    RelativeLayout admin_add_bus;

    EditText edt_roll_number, edt_password;
    EditText edt_name, edt_department, edt_mobile, edt_email, edt_address, edt_year, edt_semester;

    EditText driver_id,driver_password,driver_name,driver_number;
    String strLoginId;
    BottomNavigationView mBottomNavigationView;
    private final ArrayList<RegFormModel> modelArrayList = new ArrayList<>();

    private final ArrayList<DriverRegFormModel> modelArrayListd = new ArrayList<>();
    ListView listView;




    private ProgressDialog progress;
    TextView tv_no_data_found;

    private RelativeLayout filterOptionLayout;

    private CardView featuresCard;

    private Button filter;

    private ListView listViewd;
    private DriverAdapter adapter;
    private List<RegFormModel> driverList;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        strLoginId = PreferenceManager.getInstance(this).getUserId();
        edt_name = findViewById(R.id.edt_name);
        edt_department = findViewById(R.id.edt_department);
        edt_year = findViewById(R.id.edt_year);
        edt_semester = findViewById(R.id.edt_semester);
        edt_roll_number = findViewById(R.id.edt_roll_number);
        edt_password = findViewById(R.id.edt_password);

        driver_id=findViewById(R.id.driver_id);
        driver_password=findViewById(R.id.driver_password);
        driver_name=findViewById(R.id.driver_name);
        driver_number=findViewById(R.id.driver_number);


        admin_add_student = findViewById(R.id.admin_add_student);
        admin_add_bus = findViewById(R.id.admin_add_bus);


        listView = findViewById(R.id.listview);


        tv_no_data_found = findViewById(R.id.tv_no_data_found);

        filter= findViewById(R.id.filter);



        featuresCard = findViewById(R.id.featuresCard);


        TextView text_view = findViewById(R.id.tv_vehicle_info_label);



        listView = findViewById(R.id.listViewd);
        driverList = new ArrayList<>();
        adapter = new DriverAdapter(this, R.layout.driver_layout, driverList, AdminActivity.this);
        listView.setAdapter(adapter);








        mBottomNavigationView = findViewById(R.id.bottom_navigation);
        mBottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            try {
                switch (item.getItemId()) {
                    case R.id.action_home:
                        viewhome();
                        return true;
                    case R.id.action_add_student:
                        addStudent();
                        return true;

                    case R.id.view_bus:
                        addbus();
                        return true;
                    case R.id.action_close:
                        logout();
                        return true;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
            return false;
        });
        findViewById(R.id.close_bs).setOnClickListener(view -> {
          closeWindow();
        });

        findViewById(R.id.close_bs1).setOnClickListener(view -> {
            closeWindow1();
        });





        findViewById(R.id.fab_btn_submit).setOnClickListener(view -> {
            String strRno = edt_roll_number.getEditableText().toString();
            String strPwd = edt_password.getEditableText().toString();
            String strName = edt_name.getEditableText().toString();
            String strYear = edt_year.getEditableText().toString();
            String strSem = edt_semester.getEditableText().toString();
            String strDept = edt_department.getEditableText().toString();
            if (!TextUtils.isEmpty(strRno) && !TextUtils.isEmpty(strPwd) &&
                    !TextUtils.isEmpty(strName) && !TextUtils.isEmpty(strYear) &&
                    !TextUtils.isEmpty(strSem) && !TextUtils.isEmpty(strDept)) {
                sendDataToServer(strRno, strPwd,strName,strYear, strSem, strDept);


            } else {
                Toast.makeText(AdminActivity.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();

            }

        });


        findViewById(R.id.fab_btn_submit1).setOnClickListener(view -> {
            String drid = driver_id.getEditableText().toString();
            String drpw = driver_password.getEditableText().toString();
            String drname = driver_name.getEditableText().toString();
            String drnum = driver_number.getEditableText().toString();

            if (!TextUtils.isEmpty(drid) && !TextUtils.isEmpty(drpw) && !TextUtils.isEmpty(drname) && !TextUtils.isEmpty(drnum)){
                sendDriverDataToServer(drid,drpw,drname,drnum);


            } else {
                Toast.makeText(AdminActivity.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();

            }

        });




        CardView view_s = findViewById(R.id.view_student);
        view_s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filter.setVisibility(View.VISIBLE);
                featuresCard.setVisibility(View.GONE);


                text_view.setText("Student Information");

                getStudentList();

            }
        });

        CardView view_m = findViewById(R.id.view_map);
        view_m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(AdminActivity.this, MapsActivity.class);
                intent.putExtra("source", "Admin");
                startActivity(intent);

            }
        });

        CardView view_bus_info = findViewById(R.id.view_bus_info);
        view_bus_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                featuresCard.setVisibility(View.GONE);
                text_view.setText("Driver Information");


                getdriverList();

            }
        });


















        filterOptionLayout = findViewById(R.id.filter_option);
        filter.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (filterOptionLayout.getVisibility() == View.VISIBLE) {
                    filterOptionLayout.setVisibility(View.GONE);
                } else {
                    filterOptionLayout.setVisibility(View.VISIBLE);
                }
            }
        });



        Button option1_button = findViewById(R.id.option1_button);
        option1_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String year ="1";
                getStudentList(year);
                filterOptionLayout.setVisibility(View.GONE);

            }
        });

        Button option2_button = findViewById(R.id.option2_button);
        option2_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String year ="2";
                getStudentList(year);
                filterOptionLayout.setVisibility(View.GONE);
            }
        });

        Button option3_button = findViewById(R.id.option3_button);
        option3_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String year ="3";
                getStudentList(year);
                filterOptionLayout.setVisibility(View.GONE);

            }
        });

        Button option4_button = findViewById(R.id.option4_button);
        option4_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String year ="4";
                getStudentList(year);
                filterOptionLayout.setVisibility(View.GONE);
            }
        });
        Button option5_button = findViewById(R.id.option5_button);
        option5_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getStudentList();
                filterOptionLayout.setVisibility(View.GONE);

            }
        });

    }





    private void closeWindow() {
        admin_add_student.setVisibility(View.GONE);
        mBottomNavigationView.setVisibility(View.VISIBLE);
        mBottomNavigationView.setSelectedItemId(R.id.action_home);

    }

    private void closeWindow1() {
        admin_add_bus.setVisibility(View.GONE);
        mBottomNavigationView.setVisibility(View.VISIBLE);
        mBottomNavigationView.setSelectedItemId(R.id.action_home);

    }

    private void logout() {
        startActivity(new Intent(AdminActivity.this, AuthenticationActivity.class));
        finish();
    }

    private void viewhome() {
        featuresCard.setVisibility(View.VISIBLE);
        listView.setVisibility(View.GONE);
        filter.setVisibility(View.GONE);
        TextView text_view1 = findViewById(R.id.tv_vehicle_info_label);

        text_view1.setText("Admin Home");

    }

    private void addStudent() {
        admin_add_student.setVisibility(View.VISIBLE);
        mBottomNavigationView.setVisibility(View.GONE);

        Button filter1 = findViewById(R.id.filter);
        filter1.setVisibility(View.GONE);

    }
    private void addbus(){
        admin_add_bus.setVisibility(View.VISIBLE);

        mBottomNavigationView.setVisibility(View.GONE);


    }

    private void sendDataToServer(String strRno, String strPwd, String strName, String strYear, String strSem, String strDept) {
        RegFormModel model = new RegFormModel(strRno, strPwd, strName, strYear, strSem, strDept);
        FirebaseDatabase.getInstance().getReference("student").child(strRno).setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(AdminActivity.this, "Student details updated successfully", Toast.LENGTH_SHORT).show();
                closeWindow();
            }
        }).addOnFailureListener(e -> {
            Log.e("sendDataToServer: ", e.getMessage());
            Toast.makeText(AdminActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }
    private void sendDriverDataToServer(String drid, String drpw, String drname, String drnum) {
        DriverRegFormModel driver = new DriverRegFormModel(drid, drpw, drname, drnum);
        FirebaseDatabase.getInstance().getReference("driverinfo").child(drid).setValue(driver)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(AdminActivity.this, "Driver details updated successfully", Toast.LENGTH_SHORT).show();
                        closeWindow1();
                    }
                }).addOnFailureListener(e -> {
                        Log.e("sendDriverDataToServer: ", e.getMessage());
                        Toast.makeText(AdminActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                });
    }








    private void getStudentList(String selectedYear) {
        progress = new ProgressDialog(this);
        progress.setMessage("Please wait");
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.setIndeterminate(true);
        progress.setProgress(0);
        progress.show();

        FirebaseDatabase.getInstance().getReference("student").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Iterable<DataSnapshot> snapshotIterator = dataSnapshot.getChildren();
                Iterator<DataSnapshot> iterator = snapshotIterator.iterator();
                modelArrayList.clear();
                progress.dismiss();
                while (iterator.hasNext()) {
                    RegFormModel bean = new RegFormModel();
                    DataSnapshot next = iterator.next();
                    bean.rno = (String) next.child("rno").getValue();
                    bean.name = (String) next.child("name").getValue();
                    bean.year = String.valueOf(next.child("year").getValue());
                    bean.semester = String.valueOf(next.child("semester").getValue());
                    bean.pwd = String.valueOf(next.child("pwd").getValue());
                    bean.department = String.valueOf(next.child("department").getValue());

                    // Check if the student belongs to the selected year
                    if (bean.year.equals(selectedYear)) {
                        modelArrayList.add(bean);
                    }
                }
                // Check if any students were found for the selected year
                if (modelArrayList.size() > 0) {
                    listView.setVisibility(View.VISIBLE);
                    tv_no_data_found.setVisibility(View.GONE);
                    StudentAdapter adapter = new StudentAdapter(getApplicationContext(), R.layout.student_layout, modelArrayList, AdminActivity.this);
                    listView.setAdapter(adapter);
                } else {
                    listView.setVisibility(View.GONE);
                    tv_no_data_found.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle error
            }
        });
    }




    private void getStudentList() {
        progress = new ProgressDialog(this);
        progress.setMessage("Please wait");
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.setIndeterminate(true);
        progress.setProgress(0);
        progress.show();
        FirebaseDatabase.getInstance().getReference("student").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Iterable<DataSnapshot> snapshotIterator = dataSnapshot.getChildren();
                Iterator<DataSnapshot> iterator = snapshotIterator.iterator();
                modelArrayList.clear();
                progress.dismiss();
                while (iterator.hasNext()) {
                    RegFormModel bean = new RegFormModel();
                    DataSnapshot next = iterator.next();
                    bean.rno = (String) next.child("rno").getValue();
                    bean.name = (String) next.child("name").getValue();
                    bean.year = String.valueOf(next.child("year").getValue());
                    bean.semester = String.valueOf(next.child("semester").getValue());
                    bean.pwd = String.valueOf(next.child("pwd").getValue());
                    bean.department = String.valueOf(next.child("department").getValue());
                    modelArrayList.add(bean);
                }
                if(modelArrayList.size()>0){
                    listView.setVisibility(View.VISIBLE);
                    tv_no_data_found.setVisibility(View.GONE);
                    StudentAdapter adapter = new StudentAdapter(getApplicationContext(), R.layout.student_layout, modelArrayList,AdminActivity.this);
                    listView.setAdapter(adapter);
                }else{
                    listView.setVisibility(View.GONE);
                    tv_no_data_found.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progress.dismiss();
                Log.e("student", "Failed to read user", databaseError.toException());
            }
        });
    }

    private void getdriverList() {
        progress = new ProgressDialog(this);
        progress.setMessage("Please wait");
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.setIndeterminate(true);
        progress.setProgress(0);
        progress.show();
        FirebaseDatabase.getInstance().getReference("driverinfo").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Iterable<DataSnapshot> snapshotIterator = dataSnapshot.getChildren();
                Iterator<DataSnapshot> iterator = snapshotIterator.iterator();
                driverList.clear();
                progress.dismiss();
                while (iterator.hasNext()) {
                    RegFormModel bean = new RegFormModel();
                    DataSnapshot next = iterator.next();
                    bean.dname=(String)next.child("dname").getValue() ;
                    bean.id=(String)next.child("id").getValue() ;
                    bean.number=(String)next.child("number").getValue() ;
                    driverList.add(bean);
                    String TAG = null;
                    Log.d(TAG, "onDataChange: "+driverList);
                }
                if(driverList.size()>0){
                    listView.setVisibility(View.VISIBLE);
                    tv_no_data_found.setVisibility(View.GONE);
                    DriverAdapter adapter = new DriverAdapter(getApplicationContext(), R.layout.driver_layout, driverList,AdminActivity.this);
                    listView.setAdapter(adapter);
                }else{
                    listView.setVisibility(View.GONE);
                    tv_no_data_found.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progress.dismiss();
                Log.e("driverinfo", "Failed to read user", databaseError.toException());
            }
        });
    }


    @Override
    public void OnClickDelete(String rno) {
        progress = new ProgressDialog(this);
        progress.setMessage("Please wait");
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.setIndeterminate(true);
        progress.setProgress(0);
        progress.show();
        FirebaseDatabase.getInstance().getReference("student").child(rno).removeValue(new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
                progress.dismiss();
                Toast.makeText(AdminActivity.this,"Success",Toast.LENGTH_SHORT).show();
            }
        });
    }
}