package com.sis.cbtgps;

public class DriverRegFormModel {

        public String id;
        public String password;
        public String number;
        public String dname;
        public DriverRegFormModel(String drid, String drpw, String drname, String drnum) {
            this.id = drid;
            this.password = drpw;
            this.dname = drname;
            this.number = drnum;
        }
    }

