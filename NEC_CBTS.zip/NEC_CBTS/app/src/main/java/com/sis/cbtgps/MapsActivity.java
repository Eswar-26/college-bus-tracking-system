package com.sis.cbtgps;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

import com.google.maps.android.SphericalUtil;

import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;
import static com.sis.cbtgps.AppConstant.COLLEGE_LATITUDE;
import static com.sis.cbtgps.AppConstant.COLLEGE_LONGITUDE;
import static com.sis.cbtgps.AppConstant.COLLEGE_NAME;
import static com.sis.cbtgps.AppConstant.DRIVER_NAME;
import static com.sis.cbtgps.AppConstant.MAP_ZOOM_LEVEL;
import static com.sis.cbtgps.GPSInfo.GPS_REQUEST;
import androidx.appcompat.app.AppCompatActivity;

import static java.time.chrono.MinguoChronology.INSTANCE;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.text.DecimalFormat;
import java.util.ArrayList;

public class MapsActivity extends AppCompatActivity
        implements OnMapReadyCallback ,GoogleMap.OnMarkerClickListener {
    private GoogleMap mMap;
    private ArrayList<String> permissionsToRequest;
    private final ArrayList<String> permissionsRejected = new ArrayList<>();
    private final ArrayList<String> permissions = new ArrayList<>();
    private static final String TAG = MapsActivity.class.getSimpleName();
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private static final int ALL_PERMISSIONS_RESULT = 101;
    private static final long UPDATE_INTERVAL = 5000;  /* 5 secs */
    private static final long FASTEST_INTERVAL = 5000; /* 5 secs */
    LatLng myLocationMarker;
    LatLng myBusLocationMarker;

    private Marker mCurrLocationMarker;

    private ImageView sosService;

    private TextView driverNameTextView,st;
    private TextView driverNumberTextView;

    LatLng duplicateMyLocationMarker;

    private static final int CALL_PERMISSION_REQUEST_CODE = 101;



    private final int MY_PERMISSIONS_REQUEST_LOCATION = 1;
    double currentLocationLatitude, currentLocationLongitude, currentLocationAccuracy, currentLocationAltitude;
    LocationManager mlocManager;

    private CardView cardView;
    private ImageView tvOptions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        duplicateMyLocationMarker = new LatLng(0, 0);

        Button callButton = findViewById(R.id.call_button);

        driverNameTextView = findViewById(R.id.driver_name);
        driverNumberTextView = findViewById(R.id.driver_number);
        st=findViewById(R.id.st);



        cardView = findViewById(R.id.card_view);
        tvOptions = findViewById(R.id.tv_options);


        tvOptions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cardView.getVisibility() == View.VISIBLE) {
                    cardView.setVisibility(View.GONE);
                } else {
                    cardView.setVisibility(View.VISIBLE);
                    fetchDriverDetails();
                }
            }
        });


        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the phone number from the TextView
                String phoneNumber = driverNumberTextView.getText().toString().trim();

                // Create a confirmation dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(MapsActivity.this);
                builder.setTitle("Confirm Call");
                builder.setMessage("Do you want to call the Driver?");
                builder.setPositiveButton("Call", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Create an intent to open the phone app with the phone number
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:" + phoneNumber));

                        // Check if the device supports making calls
                        if (intent.resolveActivity(getPackageManager()) != null) {
                            // Request permission to make a phone call if not already granted
                            if (ActivityCompat.checkSelfPermission(MapsActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                ActivityCompat.requestPermissions(MapsActivity.this, new String[]{Manifest.permission.CALL_PHONE}, CALL_PERMISSION_REQUEST_CODE);
                            } else {
                                // Start the phone activity
                                startActivity(intent);
                            }
                        } else {
                            // Handle if the device doesn't support making calls
                            Toast.makeText(MapsActivity.this, "Your device doesn't support phone calls", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("Cancel", null);
                builder.show();
            }
        });






        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        permissions.add(ACCESS_FINE_LOCATION);
        permissions.add(ACCESS_COARSE_LOCATION);

        permissionsToRequest = findUnAskedPermissions(permissions);
        //get the permissions we have asked for before but are not granted..
        //we will store this in a global list to access later.

        FirebaseDatabase mFirebaseInstance = FirebaseDatabase.getInstance();

        // get reference to 'users' node
        DatabaseReference mFirebaseDatabase = mFirebaseInstance.getReference("driver");

        // store app title to 'app_title' node
        mFirebaseInstance.getReference("app_title").setValue("Vehical Tracking");

        mFirebaseDatabase.child("0001").addValueEventListener(new ValueEventListener() {






            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                LocationBean locationBean = dataSnapshot.getValue(LocationBean.class);

                // Check for null
                if (locationBean == null) {
                    Log.e(TAG, "location data is null!");
                    return;
                }

                if (myLocationMarker == null) {
                    // Send last known location
                    getLastLocation();
                    return;
                }

                myBusLocationMarker = new LatLng(locationBean.latitude, locationBean.longitude);
                String for1;
                if (myBusLocationMarker == null)
                {
                    for1 = String.format("null");
                }
                else {
                    for1 = String.format("on");

                }


                Log.e(TAG, "location data is changed!" + locationBean.latitude + ", " + locationBean.longitude);
                mMap.clear();


                // String estimatedTime = getEstimatedTime(new LatLng(locationBean.latitude, locationBean.longitude), myLocationMarker);
                double distanceInKm = calculateDistance(locationBean.latitude, locationBean.longitude,COLLEGE_LATITUDE, COLLEGE_LONGITUDE);


                double distanceInKm1 = calculateDistance(locationBean.latitude, locationBean.longitude, myLocationMarker.latitude ,myLocationMarker.longitude);

                String estimatedTime = calculateEstimatedTime(distanceInKm);

                String estimatedTime1 = calculateEstimatedTime(distanceInKm1);



                double locationBeanLatitude = locationBean.latitude;
                double locationBeanLongitude = locationBean.longitude;
                double collegeLatitude = COLLEGE_LATITUDE;
                double collegeLongitude = COLLEGE_LONGITUDE;

                double b_c_distance = calculateDistance(locationBeanLatitude, locationBeanLongitude, collegeLatitude, collegeLongitude);
                double b_p_distance = calculateDistance(locationBeanLatitude, locationBeanLongitude, myLocationMarker.latitude, myLocationMarker.longitude);


                String formattedDistance = String.format("%.2f", b_c_distance);
                String formattedDistance1 = String.format("%.2f", b_p_distance);


                TextView bus_c_t_and_d = findViewById(R.id.bus_c_t_and_d);
                TextView bus_person_t_and_d = findViewById(R.id.bus_person_t_and_d);

                String bus_college_d = "Distance between bus and college: " + formattedDistance + " km, \nEstimated Time: " + estimatedTime;
                bus_c_t_and_d.setText(bus_college_d);

                String currBusDis = "Current Position to bus " + formattedDistance1 + " km, \nEstimated Time: " +estimatedTime1;
                bus_person_t_and_d.setText(currBusDis);

                if (estimatedTime1 =="0"){
                    bus_c_t_and_d.setVisibility(View.VISIBLE);
                    bus_person_t_and_d.setVisibility(View.GONE);

                }
                if (estimatedTime1 !="0")
                {
                    bus_person_t_and_d.setVisibility(View.VISIBLE);
                    bus_c_t_and_d.setVisibility(View.GONE);
                }








                mMap.addMarker(new MarkerOptions()

                        .position(new LatLng(locationBean.latitude, locationBean.longitude))
                        .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_action_bus_station))
                        .title("Driver Location "));
                mMap.addMarker(new MarkerOptions()
                        .position(new LatLng(myLocationMarker.latitude, myLocationMarker.longitude))
                        .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_action_male))
                        .title("Current location"));
                mMap.addMarker(new MarkerOptions()
                        .position(new LatLng(COLLEGE_LATITUDE, COLLEGE_LONGITUDE))
                        .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_action_university))
                        .title("Narayana Engineering College"));
            }



            private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
                final int R = 6371; // Radius of the Earth in kilometers
                double latDistance = Math.toRadians(lat2 - lat1);
                double lonDistance = Math.toRadians(lon2 - lon1);
                double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                        + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                        * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
                double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                double distance = R * c;

                return distance;
                // Distance in kilometers
            }

            // Method to calculate the estimated travel time between two points
            private String calculateEstimatedTime(double distanceInKm) {
                double averageSpeedKmPerHour=0;
                if(distanceInKm >10)
                {
                    averageSpeedKmPerHour=50.0;
                }
                else{
                    averageSpeedKmPerHour =15.0;
                }
                // Adjust this value based on your estimation

                // Calculate the estimated time in hours (distance / speed)
                double estimatedTimeHours = distanceInKm / averageSpeedKmPerHour;

                // Convert hours to minutes and seconds
                int hours = (int) estimatedTimeHours;
                int minutes = (int) ((estimatedTimeHours - hours) * 60);

                // Format the estimated time as HH:MM

                if (hours==0 && minutes <1){
                    return "0";
                }

                return String.format("%02d hr :%02d min ", hours, minutes);

            }







            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "Failed to read user", databaseError.toException());
            }
        });

        ImageView backNavImageView = findViewById(R.id.back_nav_a);
        backNavImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the source activity from the Intent extra
                String source = getIntent().getStringExtra("source");

                // Navigate back based on the source activity
                if ("HomeActivity".equals(source)) {
                    startActivity(new Intent(MapsActivity.this, HomeActivity.class));

                    finish();
                } else if ("Admin".equals(source)) {
                    startActivity(new Intent(MapsActivity.this, AdminActivity.class));
                    finish();
                }
            }
        });


    }

    private void showConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Send SOS Alert")
                .setMessage("Are you sure you want to send an SOS alert?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setNegativeButton("No", null)
                .show();
    }


    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        LatLng markerPosition = (myLocationMarker != null) ? myLocationMarker : duplicateMyLocationMarker;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mMap.setMyLocationEnabled(true);
        mMap.setTrafficEnabled(true);
        mMap.addMarker(new MarkerOptions()
                .position(markerPosition)
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_action_male))
                .title("Current location"));
        getLastLocation();

        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mMap.setMyLocationEnabled(true);
        mMap.setTrafficEnabled(true);
        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(COLLEGE_LATITUDE, COLLEGE_LONGITUDE))
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_action_university))
                .title(COLLEGE_NAME));
    }

    private void getLastLocation() {
        FusedLocationProviderClient locationClient = getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mlocManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationClient.getLastLocation()
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        // Update both myLocationMarker and duplicateMyLocationMarker
                        myLocationMarker = new LatLng(location.getLatitude(), location.getLongitude());
                        duplicateMyLocationMarker = myLocationMarker;
                        onLocationChanged(location);
                    }
                })
                .addOnFailureListener(Throwable::printStackTrace);
    }


    private ArrayList<String> findUnAskedPermissions(ArrayList<String> wanted) {
        ArrayList<String> result = new ArrayList<>();
        for (String perm : wanted) {
            if (!hasPermission(perm)) {
                result.add(perm);
            }
        }
        return result;
    }

    @Override
    protected void onResume() {
        super.onResume();
        requestGpsPermission();
    }

    private boolean hasPermission(String permission) {
        if (canMakeSmores()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED);
            }
        }
        return true;
    }

    private boolean canMakeSmores() {
        return (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
    }

    private void showMessageOKCancel(DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(MapsActivity.this)
                .setMessage("These permissions are mandatory for the application. Please allow access.")
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_dist_bet_driver_student:

                getDistance(1, myBusLocationMarker.latitude, myBusLocationMarker.longitude, COLLEGE_LATITUDE, COLLEGE_LONGITUDE);
                break;
            case R.id.menu_dist_bet_student_college:
                getDistance(2, myLocationMarker.latitude, myLocationMarker.longitude, COLLEGE_LATITUDE, COLLEGE_LONGITUDE);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void getDistance(int value, double fromLatitude, double fromLongitude, double toLatitude, double toLongitude) {
        String travelDistance = getApproixmateDistance(fromLatitude, fromLongitude, toLatitude, toLongitude);
        if (value == 1) {
            Toast.makeText(MapsActivity.this, "Distance between driver and student : " + travelDistance, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MapsActivity.this, "Distance between student and college : " + travelDistance, Toast.LENGTH_SHORT).show();
        }
    }

    private String getApproixmateDistance(double fromLatitude, double fromLongitude, double toLatitude, double toLongitude) {
        LatLng from = new LatLng(fromLatitude, fromLongitude);
        LatLng to = new LatLng(toLatitude, toLongitude);
        Double distance = SphericalUtil.computeDistanceBetween(from, to);
        DecimalFormat df = new DecimalFormat("###.##");
        return df.format(distance / 1000) + " Km";
    }

    @Override
    public boolean onMarkerClick(@NonNull Marker marker) {
        return false;
    }



    private void onLocationChanged(Location location) {
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }

        //Place current location marker
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        myLocationMarker = latLng;
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("Current Position");
        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_action_male));
        mCurrLocationMarker = mMap.addMarker(markerOptions);

        //move map camera
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(MAP_ZOOM_LEVEL));
    }


    public void requestGpsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                GPSInfo.getInstance(MapsActivity.this).turnGPSOn(isGPSEnable -> {
                    if (isGPSEnable)
                        getLastLocation();
                });
            } else {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
            }
        } else {
            GPSInfo.getInstance(MapsActivity.this).turnGPSOn(isGPSEnable -> {
                if (isGPSEnable)
                    getLastLocation();
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == MY_PERMISSIONS_REQUEST_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    getLastLocation();
                }
            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Please provide GPS permission")
                        .setCancelable(false)
                        .setPositiveButton("Settings", (dialog, id) -> {
                            Intent intent = new Intent();
                            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            startActivity(intent);
                            finish();
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }
        }
    }


    private void fetchDriverDetails() {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("driver_name_number");
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String driverName = dataSnapshot.child("driver_name").getValue(String.class);
                    String driverNumber = dataSnapshot.child("driver_number").getValue(String.class);
                    String driverst = dataSnapshot.child("driver_status").getValue(String.class);

                    driverNameTextView.setText("Driver Name : "+driverName != null ? driverName : "Driver Name");
                    driverNumberTextView.setText("Driver Number : "+driverNumber != null ? driverNumber : "Driver Number");

                   st.setText("Service Status"+driverst != null ? driverst : "Service Status");



                } else {
                    Toast.makeText(MapsActivity.this, "Driver details not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MapsActivity.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
