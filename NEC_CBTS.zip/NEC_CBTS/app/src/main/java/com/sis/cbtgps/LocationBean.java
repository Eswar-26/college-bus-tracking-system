package com.sis.cbtgps;


public class LocationBean {
    public double latitude;
    public double longitude;

    public LocationBean() {

    }

    public LocationBean(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

}
