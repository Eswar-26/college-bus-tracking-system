package com.sis.cbtgps;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileActivity extends AppCompatActivity {
    String rollNumber;
    private ProgressDialog progress;
    TextView tv_id, txt_address, tv_email, tv_mobile, txt_name, txt_department, txt_year_semester, txt_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        rollNumber = PreferenceManager.getInstance(this).getUserId();
        tv_id = findViewById(R.id.tv_id);
        txt_name = findViewById(R.id.txt_name);
        txt_department = findViewById(R.id.txt_department);
        txt_year_semester = findViewById(R.id.txt_year_semester);
        txt_password = findViewById(R.id.txt_password);
        findViewById(R.id.toolbar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        getStudentList();
    }

    private void getStudentList() {
        {
            progress = new ProgressDialog(this);
            progress.setMessage("Please wait");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setIndeterminate(true);
            progress.setProgress(0);
            progress.show();
            FirebaseDatabase.getInstance().getReference("student/" + rollNumber).addValueEventListener(new ValueEventListener() {

                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    progress.dismiss();
                    DataSnapshot next = dataSnapshot;
                    tv_id.setText((String) next.child("rno").getValue());
                    txt_name.setText((String) next.child("name").getValue());
                    txt_password.setText((String) next.child("pwd").getValue());
                    txt_department.setText((String) next.child("department").getValue());
                    txt_year_semester.setText(next.child("year").getValue() + "-" + next.child("semester").getValue());
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    progress.dismiss();
                    Log.e("student", "Failed to read user", databaseError.toException());
                }
            });
        }
    }
}