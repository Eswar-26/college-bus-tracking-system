package com.sis.cbtgps;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceManager {
    private static PreferenceManager sPreferenceManager;
    private final SharedPreferences mSharedPreferences;

    private static final String USER_ROLE = "user_role";
    private static final String USER_ID = "user_id";

    private PreferenceManager(Context context) {
        mSharedPreferences = context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);
    }

    public static PreferenceManager getInstance(Context context) {
        if (sPreferenceManager == null) {
            sPreferenceManager = new PreferenceManager(context);
        }
        return sPreferenceManager;
    }

    public void clearInstance() {
        sPreferenceManager = null;
    }

    public void setUserRole(int id) {
        mSharedPreferences.edit().putInt(USER_ROLE, id).apply();
    }

    public int getUserRole() {
        return mSharedPreferences.getInt(USER_ROLE, -1);
    }

    public void setUserId(String authId) {
        mSharedPreferences.edit().putString(USER_ID, authId).apply();
    }

    public String getUserId() {
        return mSharedPreferences.getString(USER_ID, "");
    }
}
