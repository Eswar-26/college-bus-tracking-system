package com.sis.cbtgps;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class DriverAdapter extends ArrayAdapter<RegFormModel> {

    private Context context;
    private List<RegFormModel> drivers;

    public DriverAdapter(Context context, int driver_layout, List<RegFormModel> drivers, AdminActivity adminActivity) {
        super(context, R.layout.driver_layout, drivers);
        this.context = context;
        this.drivers = drivers;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.driver_layout, parent, false);
        }

        RegFormModel driver = drivers.get(position);

        TextView idTextView = convertView.findViewById(R.id.dr_id);
        TextView nameTextView = convertView.findViewById(R.id.dr_name);
        TextView phoneTextView = convertView.findViewById(R.id.dr_phone);
        ImageView deleteImageView = convertView.findViewById(R.id.img_deleted);


        idTextView.setText("Id : "+driver.id);
        nameTextView.setText("Driver Name : "+driver.dname);
        phoneTextView.setText("Driver Number : "+driver.number);

        deleteImageView.setOnClickListener(v -> {
            deleteDriver(driver.id);
            drivers.remove(position);
            notifyDataSetChanged();
            Toast.makeText(context, "Driver deleted", Toast.LENGTH_SHORT).show();
        });


        return convertView;
    }
    private void deleteDriver(String driverId) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("driverinfo").child(driverId);
        reference.removeValue().addOnSuccessListener(aVoid -> {
            // Data deleted successfully
            Toast.makeText(context, "Driver deleted from database", Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(e -> {
            // Failed to delete data
            Toast.makeText(context, "Failed to delete driver", Toast.LENGTH_SHORT).show();
        });
    }
}
