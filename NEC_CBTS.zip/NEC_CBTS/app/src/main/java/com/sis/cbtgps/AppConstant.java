package com.sis.cbtgps;

class AppConstant {

    public static final int SPLASH_TIME_OUT = 2000;
//14.4331203,79.9922859
    public static final double COLLEGE_LATITUDE = 14.4330723;
    public static final double COLLEGE_LONGITUDE = 79.9946828;
    public static final float MAP_ZOOM_LEVEL = 12;
    public static final String DRIVER_NAME = "Driver Location";
    public static final String COLLEGE_NAME = "Narayana engineering college";

    public static final String SENDER_EMAIL = "teswart2002@gmail.com";
    public static final String SENDER_PASSWORD = "lqjgyqfznxgatloh";
    public static final String RECEIVER_EMAIL = "teswart2002@gmail.com";

    public static final String SUBJECT = "Feedback";
    public static final String MESSAGE = "Test message from college bus tracking system app";

    //AIzaSyB2UYADztOZk8ZgzSzTRExBIPZY6j24INI
    //AIzaSyD72pMh9OsoN-YNKNorU09Opjp3Z-E1dFM
    //AIzaSyC22GfkHu9FdgT9SwdCWMwKX1a4aohGifM
    public static final String DISTANCE_API_KEY = "AIzaSyD72pMh9OsoN-YNKNorU09Opjp3Z-E1dFM";
}
