package com.sis.cbtgps;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AuthenticationActivity extends BaseActivity {
    private final Context mContext = AuthenticationActivity.this;
    private EditText edt_pwd;
    private EditText edt_login_id;
    private String strLoginId;
    private String strPassword;
    private TextView txt_new_register;
    private TextView txt_label_login;
    private TextView btn_login;
    private boolean isLoginFlag = true;
    private ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication);
        initilize();
    }

    private void initilize() {

        edt_login_id = findViewById(R.id.edt_login_id);
        edt_pwd = findViewById(R.id.edt_pwd);

        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               //startActivity(new Intent(AuthenticationActivity.this,AdminActivity.class));
                if(isValidUser()){
                    if(strLoginId.equals("admin") && strPassword.equals("admin")){
                        startActivity(new Intent(AuthenticationActivity.this,AdminActivity.class));
                    }else{
                        authentication(strLoginId, strPassword);
                    }
                }
            }
        });

        txt_label_login = findViewById(R.id.txt_label_login);
    }

    private void registrationPage() {
        isLoginFlag = false;
        btn_login.setText(getString(R.string.btn_register));
        txt_label_login.setText(getString(R.string.title_registration));
        txt_new_register.setVisibility(View.INVISIBLE);
    }

    private boolean isValidUser() {
        strLoginId = edt_login_id.getText().toString();
        strPassword = edt_pwd.getText().toString();
        if (TextUtils.isEmpty(strLoginId)) {
            edt_login_id.requestFocus();
            edt_login_id.setError(getString(R.string.error_hint_mobile_empty));
            return false;
        } else if (TextUtils.isEmpty(strPassword)) {
            edt_pwd.requestFocus();
            edt_pwd.setError(getString(R.string.error_hint_password_empty));
            return false;
        }
        return true;
    }

    private void authentication(String id, final String password) {
        progress = new ProgressDialog(this);
        progress.setMessage("Please wait");
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.setIndeterminate(true);
        progress.setProgress(0);
        progress.show();

        FirebaseDatabase mFirebaseInstance = FirebaseDatabase.getInstance();
        DatabaseReference mFirebaseDatabase = mFirebaseInstance.getReference("student");
        mFirebaseDatabase.child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                RegFormModel formbean = dataSnapshot.getValue(RegFormModel.class);
                if (formbean != null) {
                    if (formbean.pwd.equals(password)) {
                        progress.dismiss();
                        PreferenceManager.getInstance(AuthenticationActivity.this).setUserId(id);
                        startActivity(new Intent(AuthenticationActivity.this, HomeActivity.class));
                        finish();
                    } else {
                        progress.dismiss();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progress.dismiss();
                Toast.makeText(AuthenticationActivity.this, "Invalid login details", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
