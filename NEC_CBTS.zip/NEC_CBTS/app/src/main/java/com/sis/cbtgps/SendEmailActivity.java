package com.sis.cbtgps;

import static com.sis.cbtgps.AppConstant.MESSAGE;
import static com.sis.cbtgps.AppConstant.RECEIVER_EMAIL;
import static com.sis.cbtgps.AppConstant.SENDER_EMAIL;
import static com.sis.cbtgps.AppConstant.SENDER_PASSWORD;
import static com.sis.cbtgps.AppConstant.SUBJECT;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SendEmailActivity extends AppCompatActivity {
    private EditText edt_to_address;
    private EditText edt_subject;
    private EditText edt_message;
    private final SendEmailTask sendEmailTask = new SendEmailTask();
    private String to_address;
    private String subject;
    private String message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_email);


        edt_to_address = findViewById(R.id.edt_to_address);
        EditText edt_from_address = findViewById(R.id.edt_from_address);
        edt_subject = findViewById(R.id.edt_subject);
        edt_message = findViewById(R.id.edt_message);

        edt_to_address.setText(RECEIVER_EMAIL);
        edt_from_address.setText(SENDER_EMAIL);
        edt_subject.setText("");
        edt_message.setText("");
        findViewById(R.id.toolbar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        findViewById(R.id.button_send_email).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                to_address = edt_to_address.getEditableText().toString();
                subject = edt_subject.getEditableText().toString();
                message = edt_message.getEditableText().toString();
                if (!TextUtils.isEmpty(to_address) && !TextUtils.isEmpty(SENDER_EMAIL) && !TextUtils.isEmpty(subject) && !TextUtils.isEmpty(message)) {
                    if (isOnline()) {
                        sendEmailTask.execute();
                        Toast.makeText(SendEmailActivity.this, "Mail Sent", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(SendEmailActivity.this, "No Internet Connection", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(SendEmailActivity.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnected();
    }

    class SendEmailTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.i("Email sending", "sending start");
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                GmailSender sender = new GmailSender(SENDER_EMAIL, SENDER_PASSWORD);
                sender.sendMail(subject, message, SENDER_EMAIL, to_address);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }
    }
}
