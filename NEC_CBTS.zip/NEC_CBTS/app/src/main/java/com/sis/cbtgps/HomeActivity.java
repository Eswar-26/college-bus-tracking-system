package com.sis.cbtgps;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {
    private LinearLayout lyt_profile;
    private LinearLayout lyt_map;
    private LinearLayout lyt_email;
    private LinearLayout lyt_logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initilize();
    }

    private void initilize() {
        lyt_profile = findViewById(R.id.lyt_profile);
        lyt_profile.setOnClickListener(this);
        lyt_map = findViewById(R.id.lyt_map);
        lyt_map.setOnClickListener(this);
        lyt_email = findViewById(R.id.lyt_email);
        lyt_email.setOnClickListener(this);
        lyt_logout = findViewById(R.id.lyt_logout);
        lyt_logout.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == lyt_profile.getId()) {
            startActivity(new Intent(HomeActivity.this, ProfileActivity.class));
        } else if (view.getId() == lyt_map.getId()) {
//            startActivity(new Intent(HomeActivity.this, MapsActivity.class));

            Intent intent = new Intent(HomeActivity.this, MapsActivity.class);
            intent.putExtra("source", "HomeActivity");
            startActivity(intent);

        } else if (view.getId() == lyt_email.getId()) {
            startActivity(new Intent(HomeActivity.this, SendEmailActivity.class));
        } else if (view.getId() == lyt_logout.getId()) {
            startActivity(new Intent(HomeActivity.this, AuthenticationActivity.class));
            finish();
        }
    }
}
