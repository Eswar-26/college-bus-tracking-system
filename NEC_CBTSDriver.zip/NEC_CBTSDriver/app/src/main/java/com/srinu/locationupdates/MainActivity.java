package com.srinu.locationupdates;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements GPSInfo.GPSLocationListener {
    private int LOCATION_PERMISSION_CODE = 1;
    private int BACKGROUND_LOCATION_PERMISSION_CODE = 2;
    public String st="Service Stopped";
    TextView tv_vehicle_location, tv_vehicle_current_address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String loginId = getIntent().getStringExtra("loginId");

        fetchAndDisplayDriverDetails(loginId);
        tv_vehicle_location = findViewById(R.id.tv_vehicle_location);
        tv_vehicle_current_address = findViewById(R.id.tv_vehicle_current_address);

        BottomNavigationView mBottomNavigationView = findViewById(R.id.bottom_navigation);
        mBottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            try {
                switch (item.getItemId()) {
                    case R.id.action_home:
                        return true;
                    case R.id.action_start_service:
                        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("driver_name_number");
                        st="Service Started";
                        databaseReference.child("driver_status").setValue(st);
                        Log.d(TAG, "ddddddddddddddd"+st);

                        checkPermission();
                        return true;
                    case R.id.action_stop_service:
                        DatabaseReference databaseReference1 = FirebaseDatabase.getInstance().getReference("driver_name_number");
                        st="Service Stopped";
                        databaseReference1.child("driver_status").setValue(st);
                        Log.d(TAG, "ddddddddddddddd"+st);

                        stopTrackerService();
                        return true;
                    case R.id.action_close:
                        DatabaseReference databaseReference2 = FirebaseDatabase.getInstance().getReference("driver_name_number");
                        st="Service Stopped";
                        databaseReference2.child("driver_status").setValue(st);
                        Log.d(TAG, "ddddddddddddddd"+st);
                        end1();

                        return true;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
            return false;
        });
    }
private void end1()
{
    stopTrackerService();
    startActivity(new Intent(MainActivity.this, Authentication.class));


}
    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    initiateGPSCapture();
                } else {

                    askPermissionForBackgroundUsage();
                }
            }
        } else {

            askForLocationPermission();
        }
    }

    private void askForLocationPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission Needed!")
                    .setMessage("Location Permission Needed!")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // Permission is denied by the user
                        }
                    })
                    .create().show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_CODE);
        }
    }
    private void askPermissionForBackgroundUsage() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission Needed!")
                    .setMessage("Background Location Permission Needed!, tap \"Allow all time in the next screen\"")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION}, BACKGROUND_LOCATION_PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // User declined for Background Location Permission.
                        }
                    })
                    .create().show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION}, BACKGROUND_LOCATION_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // User granted location permission
                // Now check if android version >= 11, if >= 11 check for Background Location Permission
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        initiateGPSCapture();
                    } else {
                        // Ask for Background Location Permission
                        askPermissionForBackgroundUsage();
                    }
                }
            } else {
                // User denied location permission
            }
        } else if (requestCode == BACKGROUND_LOCATION_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initiateGPSCapture();
            } else {
                // User declined for Background Location Permission.
            }
        }
    }

    private void initiateGPSCapture() {
        GPSInfo.getInstance(this).startLocationUpdates();
        GPSInfo.getInstance(this).setGpsLocationListener(this);
        startTrackerService();
    }

    private void startTrackerService() {
        startService(new Intent(MainActivity.this, ForegroundService.class));
        Toast.makeText(this, "GPS tracking enabled", Toast.LENGTH_SHORT).show();
//        finish();
    }

    private void stopTrackerService() {
        stopService(new Intent(MainActivity.this, ForegroundService.class));
        Toast.makeText(this, "GPS tracking disabled", Toast.LENGTH_SHORT).show();
        tv_vehicle_current_address.setText(": NA");
        tv_vehicle_location.setText(": NA");

       // finish();
    }

    @Override
    public void onLocationUpdate(double latitude, double longitude, double altitude, double accuracy, String provider) {
        tv_vehicle_location.setText("");
        tv_vehicle_location.append(": ");
        tv_vehicle_location.append(String.valueOf(latitude));
        tv_vehicle_location.append(",");
        tv_vehicle_location.append(String.valueOf(longitude));
        String strAddress = getLocationInfo(latitude, longitude);
        if (!TextUtils.isEmpty(strAddress)) {tv_vehicle_current_address.setText(": NA");
            tv_vehicle_current_address.setText(": "+strAddress);
        } else {

        }
    }

    private String getLocationInfo(double latitude, double longitude) {
        String result = null;
        Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
        try {
            List<Address> addressList = geocoder.getFromLocation(latitude, longitude, 1);
            if (addressList.size() > 0) {
                if (!TextUtils.isEmpty(addressList.get(0).getAddressLine(0))) {
                    result = addressList.get(0).getAddressLine(0);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }
    @Override
    protected void onResume() {
        super.onResume();
        Location location = GPSInfo.getInstance(this).getCurrentLocation();
        if(location!=null){
            tv_vehicle_location.setText("");
            tv_vehicle_location.append(": ");
            tv_vehicle_location.append(String.valueOf(location.getLatitude()));
            tv_vehicle_location.append(",");
            tv_vehicle_location.append(String.valueOf(location.getLongitude()));
            String strAddress = getLocationInfo(location.getLatitude(), location.getLongitude());
            if (!TextUtils.isEmpty(strAddress)) {
                tv_vehicle_current_address.setText(": "+strAddress);


            } else {
                tv_vehicle_current_address.setText(": NA");
            }
        }
    }


    private void fetchAndDisplayDriverDetails(String loginId) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("driverinfo").child(loginId);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    DriverRegFormModel driver = dataSnapshot.getValue(DriverRegFormModel.class);
                    if (driver != null) {
                        String driverName = driver.getDname();
                        String driverNumber = driver.getNumber();

                        // Update the TextViews with driver name and number
                        TextView driverNameTextView = findViewById(R.id.driver_name);
                        TextView driverNumberTextView = findViewById(R.id.driver_ph);
                        driverNameTextView.setText(": " + driverName);
                        driverNumberTextView.setText(": " + driverNumber);

                        updateDriverDetailsInFirebase(loginId, driverName, driverNumber);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateDriverDetailsInFirebase(String loginId, String driverName, String driverNumber) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("driver_name_number");
        databaseReference.child("driver_name").setValue(driverName);
        databaseReference.child("driver_number").setValue(driverNumber);




    }
}