package com.srinu.locationupdates;

public class DriverRegFormModel {
    private String id;
    private String password;
    private String dname;
    private String number;

    public DriverRegFormModel() {
        // Default constructor required for calls to DataSnapshot.getValue(DriverRegFormModel.class)
    }

    public DriverRegFormModel(String id, String password, String dname, String number) {
        this.id = id;
        this.password = password;
        this.dname = dname;
        this.number = number;
    }

    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public String getDname() {
        return dname;
    }

    public String getNumber() {
        return number;
    }
}
