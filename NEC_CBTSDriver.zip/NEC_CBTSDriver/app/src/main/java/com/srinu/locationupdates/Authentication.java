package com.srinu.locationupdates;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Authentication extends AppCompatActivity {

    private EditText edtLoginId;
    private EditText edtPwd;
    private TextView btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.authatication);

        // Initialize views
        edtLoginId = findViewById(R.id.edt_login_id);
        edtPwd = findViewById(R.id.edt_pwd);
        btnLogin = findViewById(R.id.btn_login);

        // Set login button click listener
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });
    }

    private void handleLogin() {
        String loginId = edtLoginId.getText().toString().trim();
        String password = edtPwd.getText().toString().trim();

        // Example validation
        if (loginId.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both login ID and password", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("driverinfo").child(loginId);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    DriverRegFormModel driver = dataSnapshot.getValue(DriverRegFormModel.class);
                    if (driver != null && driver.getPassword().equals(password)) {
                        Toast.makeText(Authentication.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        // Proceed to the next activity or functionality
                        Intent intent = new Intent(Authentication.this, MainActivity.class);
                        intent.putExtra("loginId", loginId);
                        startActivity(intent);
                        finish();

                    } else {
                        Toast.makeText(Authentication.this, "Invalid login ID or password", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(Authentication.this, "Driver not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Authentication.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}


