package com.srinu.locationupdates;

import static android.content.ContentValues.TAG;
import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.IntentSender;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.location.LocationManagerCompat;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

public class GPSInfo extends LocationCallback implements LocationListener {
    GPSLocationListener gpsLocationListener;
    Context mContext;
    static LocationManager mLocationManager;
    private LocationRequest mLocationRequest;
    private FusedLocationProviderClient locationClient;
    private LocationCallback locationCallback;
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 100*60;//1000*60
    private long UPDATE_INTERVAL = 500;  /* 1 sec * 1*100/
    private long FASTEST_INTERVAL = 500;     /* 0.5 sec */

    private int geoFetchType = -1; // 1 - GPS Provider , 2 - Fused Location Provider

    private static GPSInfo INSTANCE;
    private Location currentLocation;

    private SettingsClient mSettingsClient;
    private LocationSettingsRequest mLocationSettingsRequest;

    public static GPSInfo getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = new GPSInfo(context);
        }
        return INSTANCE;
    }

    private GPSInfo(Context context) {
        mContext = context;
        mLocationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        mLocationRequest.setFastestInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        mSettingsClient = LocationServices.getSettingsClient(context);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);
        mLocationSettingsRequest = builder.build();
        builder.setAlwaysShow(true);
        locationClient = getFusedLocationProviderClient(context);
    }

    public void setGpsLocationListener(GPSLocationListener listener) {
        gpsLocationListener = listener;
    }

    @SuppressLint("MissingPermission")
    public void startLocationUpdates() {
        if (locationClient != null)
            locationClient.requestLocationUpdates(mLocationRequest, this, Looper.getMainLooper());
    }

    @Override
    public void onLocationResult(LocationResult locationResult) {
        super.onLocationResult(locationResult);
        for (Location location : locationResult.getLocations()) {
            if (location != null)
               /* Log.d("GPSInfo", "Fused-accuracy: " + location.getAccuracy() + " lat: " +
                        location.getLatitude() + " long: " + location.getLongitude());*/
            currentLocation = location;
            if (location != null && gpsLocationListener != null) {
                gpsLocationListener.onLocationUpdate(location.getLatitude(), location.getLongitude(),
                        location.getAltitude(), location.getAccuracy(), location.getProvider());
                break;
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location != null) {
            currentLocation = location;
            /*Log.d("GPSInfo", "GPS-accuracy: " + location.getAccuracy() + " lat: " +
                    location.getLatitude() + " long: " + location.getLongitude());*/
            if (gpsLocationListener != null)
                gpsLocationListener.onLocationUpdate(location.getLatitude(), location.getLongitude(),
                        location.getAltitude(), location.getAccuracy(), location.getProvider());
        }
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    public interface GPSLocationListener {
        void onLocationUpdate(double latitude, double longitude, double altitude, double accuracy, String provider);
    }

    public void stopLocationUpdates() {
        if (locationClient != null)
            locationClient.removeLocationUpdates(this);

    }

    public Location getCurrentLocation() {
        return currentLocation;
    }

    public void turnGPSOn(final onGpsListener onGpsListener) {

        if (mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (onGpsListener != null) {
                onGpsListener.gpsStatus(true);
            }
        } else {
            mSettingsClient
                    .checkLocationSettings(mLocationSettingsRequest)
                    .addOnSuccessListener((Activity) mContext, new OnSuccessListener<LocationSettingsResponse>() {
                        @SuppressLint("MissingPermission")
                        @Override
                        public void onSuccess(LocationSettingsResponse locationSettingsResponse) {

                            //  GPS is already enable, callback GPS status through listener
                            if (onGpsListener != null) {
                                onGpsListener.gpsStatus(true);
                            }
                        }
                    })
                    .addOnFailureListener((Activity) mContext, new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            int statusCode = ((ApiException) e).getStatusCode();
                            switch (statusCode) {
                                case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                    try {
                                        ResolvableApiException rae = (ResolvableApiException) e;
                                        rae.startResolutionForResult((Activity) mContext, 1001);
                                    } catch (IntentSender.SendIntentException sie) {
                                        sie.printStackTrace();
                                    }
                                    break;
                                case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                    String errorMessage = "Location settings are inadequate, and cannot be " +
                                            "fixed here. Fix in Settings.";
                                    Log.e(TAG, errorMessage);
                            }
                        }
                    });
        }
    }

    public boolean isGPSEnabled() {
        if (mLocationManager != null)
            return LocationManagerCompat.isLocationEnabled(mLocationManager);
        return false;
    }

    public interface onGpsListener {
        void gpsStatus(boolean isGPSEnable);
    }
}
